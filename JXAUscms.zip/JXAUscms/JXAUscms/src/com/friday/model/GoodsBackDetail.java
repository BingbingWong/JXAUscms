package com.friday.model;

public class GoodsBackDetail {
    private Integer gId;

    private Integer goodsbackId;

    private Integer pId;

    private Integer gNum;

    public Integer getgId() {
        return gId;
    }

    public void setgId(Integer gId) {
        this.gId = gId;
    }

    public Integer getGoodsbackId() {
        return goodsbackId;
    }

    public void setGoodsbackId(Integer goodsbackId) {
        this.goodsbackId = goodsbackId;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public Integer getgNum() {
        return gNum;
    }

    public void setgNum(Integer gNum) {
        this.gNum = gNum;
    }
}