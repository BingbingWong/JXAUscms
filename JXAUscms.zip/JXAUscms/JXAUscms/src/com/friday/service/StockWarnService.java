package com.friday.service;

import java.util.List;
import java.util.Map;

public interface StockWarnService {
	public List<Object> stockWarn() throws Exception;
}
